USE [dbQLHS]
GO

/****** Object:  Table [dbo].[HocSinh]    Script Date: 09/04/2017 3:40:58 CH ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[HocSinh](
	[ID] [int] NULL,
	[HoTen] [varchar](50) NULL,
	[Tuoi] [int] NULL,
	[GioiTinh] [bit] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


