﻿namespace ImportData
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPathPackage = new System.Windows.Forms.TextBox();
            this.btnChoosePackage = new System.Windows.Forms.Button();
            this.txtPathData = new System.Windows.Forms.TextBox();
            this.btnChooseData = new System.Windows.Forms.Button();
            this.btnImportData = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPathBackup = new System.Windows.Forms.TextBox();
            this.btnChooseBackup = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.proBar = new System.Windows.Forms.ProgressBar();
            this.lblMoTa = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chọn package";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Chọn nơi chứa dữ liệu";
            // 
            // txtPathPackage
            // 
            this.txtPathPackage.Location = new System.Drawing.Point(181, 28);
            this.txtPathPackage.Margin = new System.Windows.Forms.Padding(4);
            this.txtPathPackage.Name = "txtPathPackage";
            this.txtPathPackage.ReadOnly = true;
            this.txtPathPackage.Size = new System.Drawing.Size(247, 24);
            this.txtPathPackage.TabIndex = 1;
            // 
            // btnChoosePackage
            // 
            this.btnChoosePackage.Location = new System.Drawing.Point(436, 24);
            this.btnChoosePackage.Margin = new System.Windows.Forms.Padding(4);
            this.btnChoosePackage.Name = "btnChoosePackage";
            this.btnChoosePackage.Size = new System.Drawing.Size(39, 32);
            this.btnChoosePackage.TabIndex = 2;
            this.btnChoosePackage.Text = "...";
            this.btnChoosePackage.UseVisualStyleBackColor = true;
            this.btnChoosePackage.Click += new System.EventHandler(this.btnChoosePackage_Click);
            // 
            // txtPathData
            // 
            this.txtPathData.Location = new System.Drawing.Point(181, 84);
            this.txtPathData.Margin = new System.Windows.Forms.Padding(4);
            this.txtPathData.Name = "txtPathData";
            this.txtPathData.ReadOnly = true;
            this.txtPathData.Size = new System.Drawing.Size(247, 24);
            this.txtPathData.TabIndex = 1;
            // 
            // btnChooseData
            // 
            this.btnChooseData.Location = new System.Drawing.Point(436, 80);
            this.btnChooseData.Margin = new System.Windows.Forms.Padding(4);
            this.btnChooseData.Name = "btnChooseData";
            this.btnChooseData.Size = new System.Drawing.Size(39, 32);
            this.btnChooseData.TabIndex = 2;
            this.btnChooseData.Text = "...";
            this.btnChooseData.UseVisualStyleBackColor = true;
            this.btnChooseData.Click += new System.EventHandler(this.btnChooseData_Click);
            // 
            // btnImportData
            // 
            this.btnImportData.Location = new System.Drawing.Point(52, 182);
            this.btnImportData.Margin = new System.Windows.Forms.Padding(4);
            this.btnImportData.Name = "btnImportData";
            this.btnImportData.Size = new System.Drawing.Size(112, 47);
            this.btnImportData.TabIndex = 2;
            this.btnImportData.Text = "Bắt đầu";
            this.btnImportData.UseVisualStyleBackColor = true;
            this.btnImportData.Click += new System.EventHandler(this.btnImportData_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 142);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Chọn nơi backup";
            // 
            // txtPathBackup
            // 
            this.txtPathBackup.Location = new System.Drawing.Point(181, 139);
            this.txtPathBackup.Margin = new System.Windows.Forms.Padding(4);
            this.txtPathBackup.Name = "txtPathBackup";
            this.txtPathBackup.ReadOnly = true;
            this.txtPathBackup.Size = new System.Drawing.Size(247, 24);
            this.txtPathBackup.TabIndex = 1;
            // 
            // btnChooseBackup
            // 
            this.btnChooseBackup.Location = new System.Drawing.Point(436, 135);
            this.btnChooseBackup.Margin = new System.Windows.Forms.Padding(4);
            this.btnChooseBackup.Name = "btnChooseBackup";
            this.btnChooseBackup.Size = new System.Drawing.Size(39, 32);
            this.btnChooseBackup.TabIndex = 2;
            this.btnChooseBackup.Text = "...";
            this.btnChooseBackup.UseVisualStyleBackColor = true;
            this.btnChooseBackup.Click += new System.EventHandler(this.btnChooseBackup_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Enabled = false;
            this.btnHuy.Location = new System.Drawing.Point(384, 182);
            this.btnHuy.Margin = new System.Windows.Forms.Padding(4);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(94, 47);
            this.btnHuy.TabIndex = 2;
            this.btnHuy.Text = "Ngừng";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // proBar
            // 
            this.proBar.Location = new System.Drawing.Point(181, 210);
            this.proBar.Name = "proBar";
            this.proBar.Size = new System.Drawing.Size(196, 19);
            this.proBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.proBar.TabIndex = 3;
            this.proBar.Value = 10;
            this.proBar.Visible = false;
            // 
            // lblMoTa
            // 
            this.lblMoTa.AutoSize = true;
            this.lblMoTa.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblMoTa.Location = new System.Drawing.Point(178, 189);
            this.lblMoTa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMoTa.Name = "lblMoTa";
            this.lblMoTa.Size = new System.Drawing.Size(199, 18);
            this.lblMoTa.TabIndex = 0;
            this.lblMoTa.Text = "Đang tự động nạp dữ liệu mới";
            this.lblMoTa.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 279);
            this.Controls.Add(this.proBar);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnImportData);
            this.Controls.Add(this.btnChooseData);
            this.Controls.Add(this.txtPathBackup);
            this.Controls.Add(this.txtPathData);
            this.Controls.Add(this.btnChooseBackup);
            this.Controls.Add(this.btnChoosePackage);
            this.Controls.Add(this.txtPathPackage);
            this.Controls.Add(this.lblMoTa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(507, 318);
            this.MinimumSize = new System.Drawing.Size(507, 318);
            this.Name = "Form1";
            this.Text = "Import dữ liệu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPathPackage;
        private System.Windows.Forms.Button btnChoosePackage;
        private System.Windows.Forms.TextBox txtPathData;
        private System.Windows.Forms.Button btnChooseData;
        private System.Windows.Forms.Button btnImportData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPathBackup;
        private System.Windows.Forms.Button btnChooseBackup;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.ProgressBar proBar;
        private System.Windows.Forms.Label lblMoTa;
    }
}

