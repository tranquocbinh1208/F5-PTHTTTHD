﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Security.Permissions;
using System.Diagnostics;

namespace ImportData
{
    public partial class Form1 : Form
    {
        FileSystemWatcher watcher = new FileSystemWatcher();
        string[] ArrayData = { };
        public Form1()
        {
            InitializeComponent();
        }

        private void btnChoosePackage_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Title = "Chọn đường dẫn tới package";
            dialog.Filter = "(*.dtsx)|*.dtsx";
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.FileName))
            {
                txtPathPackage.Text = dialog.FileName;
            }

        }

        private void btnImportData_Click(object sender, EventArgs e)
        {
            if (txtPathPackage.Text == "")
            {
                MessageBox.Show("Chưa chọn Package thực hiện công việc nạp dữ liệu vào CSDL");
                btnChoosePackage.Focus();
                return;
            }
            
            if (txtPathData.Text == "")
            {
                MessageBox.Show("Chưa chọn nơi chứa dữ liệu để nạp vào CSDL");
                btnChooseData.Focus();
                return;
            }
            if (txtPathBackup.Text == "")
            {
                MessageBox.Show("Chưa chọn nơi lưu dữ liệu sau khi đã nạp vào CSDL");
                btnChooseBackup.Focus();
                return;
            }

            lblMoTa.Visible = proBar.Visible = true;
            btnHuy.Enabled = true;
            btnImportData.Enabled = false;
            NapDuLieu();
            watcher = new FileSystemWatcher();
            watcher.Path = txtPathData.Text;
            watcher.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;
            watcher.Filter = "*.txt";
            watcher.Created += new FileSystemEventHandler(OnCreate);
            watcher.EnableRaisingEvents = true;
            btnHuy.Focus();
        }
        private void OnCreate(object source, FileSystemEventArgs e)
        {
           
            NapDuLieu();
        }
        private void btnChooseData_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
            {
                txtPathData.Text = dialog.SelectedPath;
            }
            
        }

        private void btnChooseBackup_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
            {
                txtPathBackup.Text = dialog.SelectedPath;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void NapDuLieu()
        {
            if (Directory.Exists(txtPathData.Text))
            {
                // Process the list of files found in the directory.
                string[] fileEntries = Directory.GetFiles(txtPathData.Text);
                foreach (string fileName in fileEntries)
                {

                    string nameOfFileData = fileName;
                    string cmdl = @"dtexec -f " + txtPathPackage.Text + @" /set \package.variables[file_import_path];" + nameOfFileData;
                    ProcessStartInfo procStart = new ProcessStartInfo("cmd.exe", "/k " + cmdl);
                    //Thuộc tính của Process
                    procStart.RedirectStandardOutput = true; //Trả về giá trị
                    procStart.UseShellExecute = false;
                    procStart.CreateNoWindow = true;//Không hiện cửa sổ window khi chạy
                    Process process = new Process();
                    process.StartInfo = procStart;
                    process.Start();
                    //wait 2s for write data to database
                    process.WaitForExit(2000);
                    process.Close();
                    //Process for rename
                    string newName = DateTime.Now.ToString().Replace(' ', '_').Replace('/', '_').Replace(':', '_');
                    string cmdMoveFile = @"ren " + nameOfFileData + " " + newName + ".txt & move " + txtPathData.Text + @"\" + newName + ".txt " + txtPathBackup.Text;
                    ProcessStartInfo procStart1 = new ProcessStartInfo("cmd.exe", "/k " + cmdMoveFile);
                    //Thuộc tính của Process
                    procStart1.RedirectStandardOutput = true; //Trả về giá trị
                    procStart1.UseShellExecute = false;
                    procStart1.CreateNoWindow = true;//Không hiện cửa sổ window khi chạy
                    Process process1 = new Process();
                    process1.StartInfo = procStart1;
                    process1.Start();
                    process1.Close();
                    
                }

            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            watcher.EnableRaisingEvents = false;
            lblMoTa.Visible = proBar.Visible = false;
            btnHuy.Enabled = false;
            btnImportData.Enabled = true;
            btnImportData.Focus();
        }
    }
}
