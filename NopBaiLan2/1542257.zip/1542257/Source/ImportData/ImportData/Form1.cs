﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.Dialogs;

namespace ImportData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private static string dataPath = "";
        private static string backupDataPath = "";
        private static string backupDataFailPath = "";
        private static string logPath = "";
        private static string pakagePath = "";
        FileSystemWatcher watcher;

        private void button1_Click(object sender, EventArgs e)
        {
            if (lbl_FolderData.Text == "")
            {
                MessageBox.Show("Vui lòng chọn thư mục chứa data");
            } else if (lbl_FolderBackup.Text == "")
            {
                MessageBox.Show("Vui lòng chọn thư mực chứa dữ liệu backup");
            } else if (lbl_FolderBackupDataFail.Text == "")
            {
                MessageBox.Show("Vui lòng chọn thư mực chứa dữ liệu backup khi bị lỗi");
            } else if (lbl_FolderLog.Text == "")
            {
                MessageBox.Show("Vui lòng chọn thư mục chứa file log");
            } else if (lbl_Pakage.Text == "")
            {
                MessageBox.Show("Vui lòng chọn file pakage");
            } else
            {
                button1.Enabled = false;
                btn_FolderBackup.Enabled = false;
                btn_FolderData.Enabled = false;
                btn_FolderBackupDataFail.Enabled = false;
                btn_FolderLog.Enabled = false;
                btn_Pakage.Enabled = false;

                dataPath = lbl_FolderData.Text;
                backupDataPath = lbl_FolderBackup.Text;
                backupDataFailPath = lbl_FolderBackupDataFail.Text;
                logPath = lbl_FolderLog.Text;
                pakagePath = lbl_Pakage.Text;

                ImportData();

                // sự kiện khi có file mới đc thêm vào
                watcher = new FileSystemWatcher()
                {
                    Path = dataPath,
                    Filter = "*.txt"
                };
                watcher.Created += new FileSystemEventHandler(OnChanged);

                watcher.EnableRaisingEvents = true;

            }
        }

        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            ImportData();
        }

        private void btn_FolderData_Click(object sender, EventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
            dialog.IsFolderPicker = true;
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                lbl_FolderData.Text = dialog.FileName;
            }
        }

        private void btn_FolderBackup_Click(object sender, EventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
            dialog.IsFolderPicker = true;
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                lbl_FolderBackup.Text = dialog.FileName;
            }
        }

        private void btn_FolderLog_Click(object sender, EventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
            dialog.IsFolderPicker = true;
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                lbl_FolderLog.Text = dialog.FileName;
            }
        }

        private void btn_FolderBackupDataFail_Click(object sender, EventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
            dialog.IsFolderPicker = true;
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                lbl_FolderBackupDataFail.Text = dialog.FileName;
            }
        }

        private void btn_Pakage_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "DTSX files | *.dtsx";
            dialog.Title = "Please select file pakage (dtsx)";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                lbl_Pakage.Text = dialog.FileName;
            }
        }
        
        private static void ImportData()
        {
            DirectoryInfo dir = new DirectoryInfo(dataPath);
            FileInfo[] TXTFiles = dir.GetFiles("*.txt");
            foreach (var file in TXTFiles)
            {
                if (file.Exists)
                {
                    string fileLogName = Path.GetFileNameWithoutExtension(file.Name) + "_" + DateTime.Today.ToString("ddMMyyyy") + ".log";
                    string fileLogPath = logPath + "\\" + fileLogName;

                    string fileBackupFailPath = backupDataFailPath + "\\" + file;

                    System.Diagnostics.Process process = new System.Diagnostics.Process();
                    System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                    startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    startInfo.FileName = "cmd.exe";
                    startInfo.Arguments = "/C dtexec /f " + pakagePath + " /set \\package.variables[File_path_import];" + file.FullName + " /set \\package.variables[File_path_log];" + fileLogPath;
                    process.StartInfo = startInfo;
                    process.Start();

                    process.WaitForExit();

                    var flag = false;
                    foreach (var line in File.ReadAllLines(fileLogPath))
                    {
                        if (line.Contains("OnError"))
                        {
                            flag = true;
                            break;
                        }
                    }

                    if (flag == true) // xảy ra lỗi. chuyển file đến backup data fail
                    {
                        File.Move(file.FullName, backupDataFailPath + "\\" + file.Name);
                    } else // thành công. chuyển file đến backup data
                    {
                        File.Move(file.FullName, backupDataPath + "\\" + file.Name);
                    }

                    process.Close();
                }
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            btn_FolderBackup.Enabled = true;
            btn_FolderData.Enabled = true;
            btn_FolderBackupDataFail.Enabled = true;
            btn_FolderLog.Enabled = true;
            btn_Pakage.Enabled = true;

            watcher.EnableRaisingEvents = false;
        }
    }
}
