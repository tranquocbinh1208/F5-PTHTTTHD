﻿namespace ImportData
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_FolderData = new System.Windows.Forms.Label();
            this.btn_FolderData = new System.Windows.Forms.Button();
            this.btn_FolderBackup = new System.Windows.Forms.Button();
            this.btn_FolderLog = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.lbl_FolderBackup = new System.Windows.Forms.Label();
            this.lbl_FolderLog = new System.Windows.Forms.Label();
            this.btn_Pakage = new System.Windows.Forms.Button();
            this.lbl_Pakage = new System.Windows.Forms.Label();
            this.btn_FolderBackupDataFail = new System.Windows.Forms.Button();
            this.lbl_FolderBackupDataFail = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 294);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 47);
            this.button1.TabIndex = 0;
            this.button1.Text = "Thực hiện";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_FolderData
            // 
            this.lbl_FolderData.AutoSize = true;
            this.lbl_FolderData.Location = new System.Drawing.Point(177, 43);
            this.lbl_FolderData.Name = "lbl_FolderData";
            this.lbl_FolderData.Size = new System.Drawing.Size(0, 13);
            this.lbl_FolderData.TabIndex = 1;
            // 
            // btn_FolderData
            // 
            this.btn_FolderData.Location = new System.Drawing.Point(12, 28);
            this.btn_FolderData.Name = "btn_FolderData";
            this.btn_FolderData.Size = new System.Drawing.Size(162, 42);
            this.btn_FolderData.TabIndex = 2;
            this.btn_FolderData.Text = "Chọn thư mục data";
            this.btn_FolderData.UseVisualStyleBackColor = true;
            this.btn_FolderData.Click += new System.EventHandler(this.btn_FolderData_Click);
            // 
            // btn_FolderBackup
            // 
            this.btn_FolderBackup.Location = new System.Drawing.Point(12, 76);
            this.btn_FolderBackup.Name = "btn_FolderBackup";
            this.btn_FolderBackup.Size = new System.Drawing.Size(162, 42);
            this.btn_FolderBackup.TabIndex = 3;
            this.btn_FolderBackup.Text = "Chọn thư mục backup";
            this.btn_FolderBackup.UseVisualStyleBackColor = true;
            this.btn_FolderBackup.Click += new System.EventHandler(this.btn_FolderBackup_Click);
            // 
            // btn_FolderLog
            // 
            this.btn_FolderLog.Location = new System.Drawing.Point(12, 172);
            this.btn_FolderLog.Name = "btn_FolderLog";
            this.btn_FolderLog.Size = new System.Drawing.Size(162, 42);
            this.btn_FolderLog.TabIndex = 4;
            this.btn_FolderLog.Text = "Chọn thư mục log";
            this.btn_FolderLog.UseVisualStyleBackColor = true;
            this.btn_FolderLog.Click += new System.EventHandler(this.btn_FolderLog_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(180, 294);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(129, 47);
            this.btnStop.TabIndex = 5;
            this.btnStop.Text = "Dừng";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // lbl_FolderBackup
            // 
            this.lbl_FolderBackup.AutoSize = true;
            this.lbl_FolderBackup.Location = new System.Drawing.Point(181, 91);
            this.lbl_FolderBackup.Name = "lbl_FolderBackup";
            this.lbl_FolderBackup.Size = new System.Drawing.Size(0, 13);
            this.lbl_FolderBackup.TabIndex = 6;
            // 
            // lbl_FolderLog
            // 
            this.lbl_FolderLog.AutoSize = true;
            this.lbl_FolderLog.Location = new System.Drawing.Point(181, 187);
            this.lbl_FolderLog.Name = "lbl_FolderLog";
            this.lbl_FolderLog.Size = new System.Drawing.Size(0, 13);
            this.lbl_FolderLog.TabIndex = 7;
            // 
            // btn_Pakage
            // 
            this.btn_Pakage.Location = new System.Drawing.Point(12, 220);
            this.btn_Pakage.Name = "btn_Pakage";
            this.btn_Pakage.Size = new System.Drawing.Size(162, 42);
            this.btn_Pakage.TabIndex = 8;
            this.btn_Pakage.Text = "Chọn file pakage (dtsx)";
            this.btn_Pakage.UseVisualStyleBackColor = true;
            this.btn_Pakage.Click += new System.EventHandler(this.btn_Pakage_Click);
            // 
            // lbl_Pakage
            // 
            this.lbl_Pakage.AutoSize = true;
            this.lbl_Pakage.Location = new System.Drawing.Point(181, 235);
            this.lbl_Pakage.Name = "lbl_Pakage";
            this.lbl_Pakage.Size = new System.Drawing.Size(0, 13);
            this.lbl_Pakage.TabIndex = 9;
            // 
            // btn_FolderBackupDataFail
            // 
            this.btn_FolderBackupDataFail.Location = new System.Drawing.Point(12, 124);
            this.btn_FolderBackupDataFail.Name = "btn_FolderBackupDataFail";
            this.btn_FolderBackupDataFail.Size = new System.Drawing.Size(162, 42);
            this.btn_FolderBackupDataFail.TabIndex = 10;
            this.btn_FolderBackupDataFail.Text = "Chọn thư mục backup data lỗi";
            this.btn_FolderBackupDataFail.UseVisualStyleBackColor = true;
            this.btn_FolderBackupDataFail.Click += new System.EventHandler(this.btn_FolderBackupDataFail_Click);
            // 
            // lbl_FolderBackupDataFail
            // 
            this.lbl_FolderBackupDataFail.AutoSize = true;
            this.lbl_FolderBackupDataFail.Location = new System.Drawing.Point(180, 139);
            this.lbl_FolderBackupDataFail.Name = "lbl_FolderBackupDataFail";
            this.lbl_FolderBackupDataFail.Size = new System.Drawing.Size(0, 13);
            this.lbl_FolderBackupDataFail.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 366);
            this.Controls.Add(this.lbl_FolderBackupDataFail);
            this.Controls.Add(this.btn_FolderBackupDataFail);
            this.Controls.Add(this.lbl_Pakage);
            this.Controls.Add(this.btn_Pakage);
            this.Controls.Add(this.lbl_FolderLog);
            this.Controls.Add(this.lbl_FolderBackup);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btn_FolderLog);
            this.Controls.Add(this.btn_FolderBackup);
            this.Controls.Add(this.btn_FolderData);
            this.Controls.Add(this.lbl_FolderData);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_FolderData;
        private System.Windows.Forms.Button btn_FolderData;
        private System.Windows.Forms.Button btn_FolderBackup;
        private System.Windows.Forms.Button btn_FolderLog;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lbl_FolderBackup;
        private System.Windows.Forms.Label lbl_FolderLog;
        private System.Windows.Forms.Button btn_Pakage;
        private System.Windows.Forms.Label lbl_Pakage;
        private System.Windows.Forms.Button btn_FolderBackupDataFail;
        private System.Windows.Forms.Label lbl_FolderBackupDataFail;
    }
}

