﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WFA_SSIS
{
    public partial class frmImport : Form
    {
        public frmImport()
        {
            InitializeComponent();
        }

        // Chọn file package
        private void btnPackage_Click(object sender, EventArgs e)
        {
            // chọn file
            OpenFileDialog file_packge = new OpenFileDialog();
            file_packge.Filter = "package|*.dtsx";

            // lấy đường dẫn

            if (file_packge.ShowDialog() == DialogResult.OK)
            {
                txtPackage.Text = file_packge.FileName;
            }
        }

        // Chọn thư mục chứa file cần import
        private void btnImport_Click(object sender, EventArgs e)
        {
            // chọn file
            OpenFileDialog file_import = new OpenFileDialog();
            file_import.Filter = "import|*.txt";

            // lấy đường dẫn

            if (file_import.ShowDialog() == DialogResult.OK)
            {
                txtImport.Text = file_import.FileName;
            }
        }

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu nhập
            if (txtPackage.Text == "" || txtImport.Text=="")
            {
                MessageBox.Show("Vui lòng chọn đầy đủ thông tin!!!", "Thông báo!!!");
            }
            else //import
            {
                string file_import = txtImport.Text;
                //MessageBox.Show(file_import);
                string file_package = txtPackage.Text;
                //MessageBox.Show(file_package);
                string comandline = string.Format(@"/C dtexec -f {0} /set \package.variables[file_path_import];{1} ", file_package, file_import);
                //MessageBox.Show(comandline);
                System.Diagnostics.Process.Start("CMD.exe", comandline);
                MessageBox.Show("Import thành công!!!", "Thông báo!!!");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
