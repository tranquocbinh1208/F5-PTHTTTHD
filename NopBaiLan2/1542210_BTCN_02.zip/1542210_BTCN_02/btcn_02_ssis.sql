CREATE DATABASE HTTT_BTCN_02_SSIS
GO
USE HTTT_BTCN_02_SSIS
GO
CREATE TABLE nhanvien
(
	id INT PRIMARY KEY IDENTITY,
	manv VARCHAR(50),
	hoten VARCHAR(50),
	diachi VARCHAR(100),
	email VARCHAR(50),
	luong MONEY
)
GO
CREATE TABLE ChiTietHoaDon
(
	MaCTHD INT PRIMARY KEY IDENTITY,
	NgayMuaHang DATE,
	SoLuong INT,
	Gia MONEY,
	MaSanPham VARCHAR(20),
	MaKH VARCHAR(20),
	XuLy INT DEFAULT(0) NOT NULL
)
GO
CREATE TABLE ChiTietHoaDon_TMP
(
	NgayMuaHang DATE,
	SoLuong INT,
	Gia MONEY,
	MaSanPham VARCHAR(20),
	MaKH VARCHAR(20),
	XuLy INT DEFAULT(0) NOT NULL
)
GO
CREATE TABLE HoaDon
(
	MaHoaDon INT PRIMARY KEY IDENTITY,
	NgayMuaHang DATE,
	NgayLapHD DATE,
	MaKH VARCHAR(20),
	TongTien MONEY
)
GO
CREATE PROC USP_TaoHoaDon
AS
BEGIN
	DECLARE @NgayMua DATE,@MaKH VARCHAR(20)
	SELECT TOP 1 @NgayMua=NgayMuaHang, @MaKH = MaKH FROM ChiTietHoaDon_TMP
	DELETE FROM ChiTietHoaDon WHERE MaKH = @MaKH AND NgayMuaHang = @NgayMua

	INSERT INTO ChiTietHoaDon (NgayMuaHang, MaKH, Gia, SoLuong, MaSanPham)
	SELECT NgayMuaHang, MaKH, Gia, SoLuong, MaSanPham
	FROM ChiTietHoaDon_TMP

	DELETE FROM HoaDon WHERE MaKH = @MaKH AND NgayMuaHang = @NgayMua

	INSERT INTO HoaDon (MaKH, NgayLapHD, NgayMuaHang, TongTien)
	SELECT cthd.MaKH,
			GETDATE(),
			cthd.NgayMuaHang,
			SUM (cthd.SoLuong * cthd.Gia)
	FROM ChiTietHoaDon cthd
	WHERE cthd.XuLy=0
	GROUP BY cthd.MaKH,cthd.NgayMuaHang

	UPDATE ChiTietHoaDon
	SET XuLy = 1
	WHERE NgayMuaHang=@NgayMua AND MaKH = @MaKH
END
GO

---test
USE HTTT_BTCN_02_SSIS
SELECT * FROM ChiTietHoaDon_TMP
SELECT * FROM ChiTietHoaDon
SELECT * FROM HoaDon